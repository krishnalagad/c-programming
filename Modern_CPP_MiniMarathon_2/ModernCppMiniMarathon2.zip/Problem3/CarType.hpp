#ifndef CARTYPE_HPP
#define CARTYPE_HPP

enum class CarType {
    PRIVATE_CAR,
    TOURIST_PERMIT_CAR
};

#endif // CARTYPE_HPP
