#ifndef FUELTYPE_HPP
#define FUELTYPE_HPP

enum class FuelType {
    DIESEL,
    PETROL,
    CNG
};

#endif // FUELTYPE_HPP
