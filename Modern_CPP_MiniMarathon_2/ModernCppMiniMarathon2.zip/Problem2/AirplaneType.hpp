#ifndef AIRPLANETYPE_HPP
#define AIRPLANETYPE_HPP

enum class AirplaneType {
    NEO,
    JUMBO,
    CRUISELINER
};

#endif // AIRPLANETYPE_HPP
